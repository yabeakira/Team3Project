drop database uniformdb;
create database uniformdb;

use uniformdb

create table userinfo(
userId INTEGER primary key auto_increment,
password varchar(20),
name varchar(100),
mail varchar(255),
address varchar(200)
)engine=InnoDB;

create table orderinfo (
orderId INTEGER primary key auto_increment,
name varchar(100),
address varchar(200),
mail varchar(100),
paymentFlag tinyint default 0,
shipmentFlag tinyint default 0,
date timestamp default current_timestamp,
remarksColumn varchar(200)
)engine=InnoDB;

create table uniforminfo (
uniformId INTEGER primary key auto_increment,
name varchar(100),
price INTEGER,
stock INTEGER,
pic_pass varchar(255)
) ENGINE = InnoDB;

create table orderpriceinfo(
orderId INTEGER unique,
uniformId INTEGER,
quantity INTEGER,
tax DOUBLE,
totalPrice INTEGER,
FOREIGN KEY (orderId) REFERENCES orderinfo (orderId) on delete cascade,
FOREIGN KEY (uniformId) REFERENCES uniforminfo (uniformId) on delete cascade
) ENGINE = InnoDB;


create table admininfo(
adminId varchar(20) primary key,
password varchar(20),
name varchar(100)
)engine=InnoDB;
