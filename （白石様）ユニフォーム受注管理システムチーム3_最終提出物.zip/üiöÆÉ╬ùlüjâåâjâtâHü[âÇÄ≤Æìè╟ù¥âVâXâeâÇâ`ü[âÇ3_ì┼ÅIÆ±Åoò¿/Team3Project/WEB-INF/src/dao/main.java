package dao;

import java.util.ArrayList;

import bean.*;

public class main {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		Order order = new Order();
		order.setName("あああ");
		order.setAddress("address");
		order.setMail("mail");
		order.setUniformId(1);
		order.setQuantity(2);
		order.setTotalPrice(2222);

		OrderDAO orderDao = new OrderDAO();
		orderDao.insert(order);

		ArrayList<Order> orderlist = orderDao.selectAll();
		for (int i = 0; i < orderlist.size(); i++) {
			System.out.println(orderlist.get(i).getOrderId() + orderlist.get(i).getDate() + "     "
					+ orderlist.get(i).getTotalPrice());

		}
		orderDao.update(10, 1, 1);
	}

}
