package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Admin;
import bean.User;

public class LogoutServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");
		Admin admin = (Admin)session.getAttribute("admin");


		session.invalidate();

		error = "ログアウトしました。";
		request.setAttribute("error", error);


		//フォワード
		if(user != null) {
			request.getRequestDispatcher("/view/login.jsp").forward(request, response);
		}else if (admin != null) {
			request.getRequestDispatcher("/view/adminLogin.jsp").forward(request, response);
		} else {
			error = "エラーが発生しました。";
			cmd = "top";
			request.setAttribute("cmd", cmd);
			request.setAttribute("error", error);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}

	}
}
