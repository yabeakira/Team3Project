package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.Cookie;

import bean.User;
import dao.UserDAO;

public class LoginServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {
			HttpSession session = request.getSession();

			//DAOオブジェクト宣言
			UserDAO userDao = new UserDAO();

			//文字エンコード
			request.setCharacterEncoding("UTF-8");

			//パラメータ取得
			String mail = request.getParameter("mail");
			String password = request.getParameter("password");

			//ユーザー情報を格納するオブジェクト生成、メソッド呼び出し
			User user = userDao.selectByMail(mail, password);

			//ユーザー検索エラー処理
			if (user.getMail() == null) {
				error = "入力データが間違っています。";
				cmd = "login";
				return;
			}

			//セッションスコープに登録
			session.setAttribute("user", user);

			//クッキーに登録
			Cookie mailCookie = new Cookie("mail", mail);
			mailCookie.setMaxAge(60*60*24*5);
			response.addCookie(mailCookie);
			Cookie passwordCookie = new Cookie("password", password);
			passwordCookie.setMaxAge(60*60*24*5);
			response.addCookie(passwordCookie);


		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ログインは出来ません。";
			cmd = "top";

		} finally {
			//フォワード
			request.setAttribute("cmd", cmd);
			request.setAttribute("error", error);
			if(cmd.equals("")) {
				//エラーがない場合
				request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
			} else if(cmd.equals("login")){
				//入力エラーがある場合
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}



	}


}
