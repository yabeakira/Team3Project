//購入機能

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Order;
import bean.Uniform;
import bean.User;
import dao.UniformDAO;
import dao.UserDAO;



public class PurchaseServlet extends HttpServlet {

	@SuppressWarnings("null")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";
		String cmd = "";

		try {

			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");
			//パラメータの取得


			String uniformId = request.getParameter("uniformId"); //商品名
			String quantity = request.getParameter("quantity");	//個数
			String login = request.getParameter("login");
			String remarksColumn = request.getParameter("remarksColumn");
			if(user == null) {
				String mail = request.getParameter("mail");
				String password = request.getParameter("password");

			//ログインせずに購入
			if (mail == null && password == null) {
				//パラメータの取得
				String name = request.getParameter("name");
				String address = request.getParameter("address");

				//リクエストスコープに登録
				Order order = new Order();
				order.setUniformId(Integer.parseInt(uniformId));
				order.setQuantity(Integer.parseInt(quantity));
				order.setName(name);
				order.setMail(mail);
				order.setAddress(address);
				order.setRemarksColumn(remarksColumn);
				request.setAttribute("order", order);


				//ログインしてたら
			}else if (login.equals("login") && !mail.equals("") && !password.equals("")) {
				UserDAO objUserDao = new UserDAO();
				User objuser = objUserDao.selectByMail(mail,password);
				if(objuser.getUserId() != 0) {
				request.setAttribute("userdetail", objuser);
				//セッションスコープに登録
				session.setAttribute("user", objuser);
				}else {
					error = "メールアドレスとパスワードを確認してください。";
					cmd = "top";
				}

				//空でログインしたら
			}else if(login.equals("login") && (mail.equals("") || password.equals(""))) {
				error = "メールアドレスとパスワードを確認してください。";
				cmd = "top";


			}else {
				//パラメータの取得
				String name = request.getParameter("name");
				String address = request.getParameter("address");

				//リクエストスコープに登録
				Order order = new Order();
				order.setUniformId(Integer.parseInt(uniformId));
				order.setQuantity(Integer.parseInt(quantity));
				order.setName(name);
				order.setMail(mail);
				order.setAddress(address);
				order.setRemarksColumn(remarksColumn);
				request.setAttribute("order", order);

			}

			}else {
				Order order = new Order();
				order.setUniformId(Integer.parseInt(uniformId));
				order.setQuantity(Integer.parseInt(quantity));
				order.setName(user.getName());
				order.setMail(user.getMail());
				order.setAddress(user.getAddress());
				order.setRemarksColumn(remarksColumn);
				request.setAttribute("order", order);
				request.setAttribute("userdetail", user);

			}
			//uniforminfoからuniformId列の全データを取得する
			UniformDAO objUniformDao = new UniformDAO();
			Uniform uniform = objUniformDao.selectByUniformId(uniformId);


			//リクエストスコープに登録
			request.setAttribute("uniform", uniform);
			request.setAttribute("uniformId", uniformId);
			request.setAttribute("quantity", quantity);


		}catch(IllegalStateException e) {
			error = "DB接続エラーのため、書籍詳細は表示できませんでした。";
			cmd = "top";
		}finally {

			if(error.equals("")) {
				request.getRequestDispatcher("/view/purchaseForm.jsp").forward(request, response);
			}else {

				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
