package servlet;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.Uniform;
import dao.UniformDAO;

public class SearchUniformServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//文字エンコード
		request.setCharacterEncoding("UTF-8");
		String error = "";
		String cmd = "";
		String name = request.getParameter("name");
		try {
			// ① UniformDAOをインスタンス化する
			UniformDAO objDao = new UniformDAO();

			// ②関連メソッドを呼び出し、戻り値としてUniformオブジェクトのリストを取得する
			ArrayList<Uniform> list = objDao.search(name);
			// 絶対パスを相対パスに変換
			// ③②で取得したListをリクエストスコープに"uniform_list"という名前で格納する
			request.setAttribute("uniform_list", list);
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");
			if (admin != null) {
				cmd = "admin";
			}

		} catch (Exception e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "top";
		} finally {
			if (error.equals("")) {
				if(cmd.equals("admin")) {
					// ④list.jspにフォワード
					request.getRequestDispatcher("/view/adminProductList.jsp").forward(request, response);
					}else {
						request.getRequestDispatcher("/view/userProductList.jsp").forward(request, response);
					}
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}
	}
}
