package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import bean.Admin;
import bean.Uniform;
import dao.UniformDAO;

@WebServlet("/InsertUniformServlet")
@MultipartConfig
public class InsertUniformServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		// エラーチェック処理用
		String error = null;
		String cmd = null;

		ServletContext servletContext = getServletContext();
		String projectFolderPath = servletContext.getRealPath("");
		final String absolutePath = projectFolderPath + "/file/pic/"; // ファイルを保存するディレクトリの絶対パス
		final String relativePath = "/file/pic/";//相対パス

		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("admin");
		if (admin == null) {
			error = "セッション切れの為、商品の登録処理は行えません。";
			cmd = "top";
			request.setAttribute("cmd", cmd);
			// エラーのリクエストスコープ登録、error.jspに遷移
			request.setAttribute("error", error);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			return;
		}

		// uniformDAOをインスタンス化する
		UniformDAO uniDao = new UniformDAO();
		// 登録データを格納する用
		Uniform uniform = new Uniform();

		request.setCharacterEncoding("UTF-8");
		String targetDirectory = absolutePath; // ファイルを保存するフォルダのパス
		Part filePart = request.getPart("fileToUpload"); // アップロードされたファイルのパートを取得

		if(filePart == null ) {
			error = "画像が未入力のため、商品登録処理は行えませんでした。";
			cmd = "admin";
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}

		String fileName = getFileName(filePart); // ファイル名を取得
		String filePath = targetDirectory + fileName; // ファイルの保存先パス

		// ファイルを指定したフォルダに保存する
		try (OutputStream out = new FileOutputStream(new File(filePath));
				InputStream fileContent = filePart.getInputStream()) {
			int read;
			byte[] buffer = new byte[1024];
			while ((read = fileContent.read(buffer)) != -1) {
				out.write(buffer, 0, read);
			}


			String name = request.getParameter("name");
			String price = request.getParameter("price");
			String stock = request.getParameter("stock");

			// 各書籍データが未入力だった時のエラー処理
			if (name.equals("")) {
				error = "商品名が未入力のため、商品登録処理は行えませんでした。";
				cmd = "admin";
				return;
			} else if (price.equals("")) {
				error = "価格が未入力のため、商品登録処理は行えませんでした。";
				cmd = "admin";
				return;
			} else if (stock.equals("")) {
				error = "在庫が未入力のため、商品登録処理は行えませんでした。";
				cmd = "admin";
				return;
			}

			uniform = uniDao.selectByUniformId(name);

			uniform.setName(name);
			uniform.setPrice(Integer.parseInt(price));
			uniform.setStock(Integer.parseInt(stock));
			// ファイルの相対パスを生成
			String setPath = relativePath + fileName;
			uniform.setPicpass(setPath);// 相対パスとして設定

			// 関連メソッドを呼び出し、戻り値としてUniformオブジェクトのリストを取得する
			uniDao.insert(uniform);
		} catch (FileNotFoundException e) {
			error = "ファイルアップロードエラーが発生しました";
			cmd = "admin";

		} catch (NumberFormatException e) {
			error = "価格の値が不正のため、商品情報登録処理は行えませんでした。";
			cmd = "admin";

		} catch (IllegalStateException e) {
			error = "DB接続エラーのため、商品登録処理は行えませんでした。";
			cmd = "top";
		} finally {
			if (error == null) {
				// AdminProductListServletにフォワード
				//一旦メニューに飛ばしてます　矢部
				response.sendRedirect(request.getContextPath() + "/uniformList");
			} else {
				request.setAttribute("cmd", cmd);
				// エラーのリクエストスコープ登録、error.jspに遷移
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

	private String getFileName(Part part) {
		String contentDisposition = part.getHeader("content-disposition");
		String[] elements = contentDisposition.split(";");
		for (String element : elements) {
			if (element.trim().startsWith("filename")) {
				return element.substring(element.indexOf('=') + 1).trim().replace("\"", "");
			}
		}
		return null;
	}
}
