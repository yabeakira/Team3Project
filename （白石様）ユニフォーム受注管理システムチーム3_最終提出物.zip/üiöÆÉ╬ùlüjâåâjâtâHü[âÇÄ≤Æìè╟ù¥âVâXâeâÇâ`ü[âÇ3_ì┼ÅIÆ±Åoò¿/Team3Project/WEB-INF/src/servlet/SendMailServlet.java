//注文更新機能

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.Order;
import dao.OrderDAO;
import util.SendMail;

public class SendMailServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";
		String cmd = "";
		SendMail reply = new SendMail();

		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("admin");
		OrderDAO orderDao = new OrderDAO();

		try {
			if (admin == null) {
				error = "セッション切れの為、注文詳細の確認は出来ません。";
				cmd = "top";
				return;
			}

			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			String orderId = request.getParameter("orderId");
			if (orderId == null) {
				error ="注文が存在しない為、メールは送信できませんでした。";
				cmd = "admin";
				return;
			}
			Order order = orderDao.selectByOrderId(orderId);
			String mail = order.getMail();

			//パラメータの取得
			String mailText = request.getParameter("mailText"); //メール本文
			if (mailText == null) {
				error ="メール本文が存在しない為、メールは送信できませんでした。";
				cmd = "admin";
				return;
			}

			reply.SendMail(mail,mailText);

		}catch(IllegalStateException e) {
			error = "DB接続エラーのため、表示できませんでした。";
			cmd = "top";

		}finally {
			if(error.equals("")) {
				response.sendRedirect(request.getContextPath() + "/orderList");
			}else {
				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
