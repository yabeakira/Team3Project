package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
//import javax.servlet.http.Cookie;

import bean.Admin;
import dao.AdminDAO;

public class AdminLoginServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {
			HttpSession session = request.getSession();

			//DAOオブジェクト宣言
			AdminDAO adminDao = new AdminDAO();

			//文字エンコード
			request.setCharacterEncoding("UTF-8");

			//パラメータ取得
			String adminId = request.getParameter("adminId");
			String password = request.getParameter("password");

			//ユーザー情報を格納するオブジェクト生成、メソッド呼び出し
			Admin admin = adminDao.selectByAdminId(adminId, password);

			//ユーザー検索エラー処理
			if (admin.getAdminId() == null) {
				error = "入力データが間違っています。";
				cmd = "login";
				return;
			}

			//セッションスコープに登録
			session.setAttribute("admin", admin);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ログインは出来ません。";
			cmd = "top";

		} finally {
			//フォワード
			request.setAttribute("cmd", cmd);
			request.setAttribute("error", error);
			if(cmd.equals("")) {
				//エラーがない場合
				request.getRequestDispatcher("/view/adminMenu.jsp").forward(request, response);
			} else if(cmd.equals("login")){
				//入力エラーがある場合
				request.getRequestDispatcher("/view/adminLogin.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}



	}


}
