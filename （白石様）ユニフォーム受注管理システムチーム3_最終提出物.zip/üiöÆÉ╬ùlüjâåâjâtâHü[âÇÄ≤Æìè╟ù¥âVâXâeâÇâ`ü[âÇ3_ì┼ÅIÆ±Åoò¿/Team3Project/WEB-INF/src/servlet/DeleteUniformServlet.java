package servlet;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.Uniform;
import dao.UniformDAO;

public class DeleteUniformServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("admin");

		try {
			if (admin == null) {
				error = "セッション切れの為、商品の削除は出来ません。";
				cmd = "top";
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				return;
			}


			//uniformDAOをインスタンス化する
			UniformDAO uniDao = new UniformDAO();

			//文字エンコード設定
			request.setCharacterEncoding("UTF-8");
			//商品名の入力パラメータを取得
			String uniformId = request.getParameter("uniformId");
			Uniform uniform = uniDao.selectByUniformId(uniformId);
			String filePath = uniform.getPicpass();
			ServletContext servletContext = getServletContext();
			String projectFolderPath = servletContext.getRealPath("");
			String absoluteFilePath = projectFolderPath + filePath;
			File file = new File(absoluteFilePath);

			file.delete();
			//delete()メソッド呼び出し
			uniDao.delete(uniformId);

		}catch (IllegalStateException e) {
			error = "DB接続エラーの為、商品の削除は行えませんでした。";
			cmd = "top";

		} finally {
			//フォワード
			request.setAttribute("cmd", cmd);
			if(error.equals("")) {
				//エラーがない場合
				// adminProductListServletにフォワード
				request.getRequestDispatcher("/uniformList").forward(request, response);
			} else {
				//エラーがある場合
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
			}
		}
	}


