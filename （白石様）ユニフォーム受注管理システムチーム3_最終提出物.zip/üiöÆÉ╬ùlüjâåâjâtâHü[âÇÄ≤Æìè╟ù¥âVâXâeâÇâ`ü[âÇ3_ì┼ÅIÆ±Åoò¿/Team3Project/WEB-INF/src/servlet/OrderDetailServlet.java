package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.Order;
import bean.Uniform;
import bean.User;
import dao.OrderDAO;
import dao.UniformDAO;

public class OrderDetailServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";
		String cmd = "";

		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("admin");
		try {
			if (admin == null) {
				error = "セッション切れの為、注文詳細の確認は出来ません。";
				cmd = "top";
				return;
			}

			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			String orderId = request.getParameter("orderId");
			String uniformId = request.getParameter("uniformId");

			OrderDAO orderDao = new OrderDAO();
			Order order = orderDao.selectByOrderId(orderId);
			if(order.getOrderId() == 0) {
				error ="表示対象の注文が存在しない為、詳細情報は表示できませんでした。";
				cmd = "admin";
				return;
			}

			UniformDAO uniformDao = new UniformDAO();
			Uniform uniform = uniformDao.selectByUniformId(uniformId);


			request.setAttribute("order",order);
			request.setAttribute("uniform",uniform);


		}catch(IllegalStateException e) {
			error = "DB接続エラーのため、注文詳細は表示できませんでした。";
			cmd = "top";

		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/view/orderedDetail.jsp").forward(request, response);
			}else {
				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
