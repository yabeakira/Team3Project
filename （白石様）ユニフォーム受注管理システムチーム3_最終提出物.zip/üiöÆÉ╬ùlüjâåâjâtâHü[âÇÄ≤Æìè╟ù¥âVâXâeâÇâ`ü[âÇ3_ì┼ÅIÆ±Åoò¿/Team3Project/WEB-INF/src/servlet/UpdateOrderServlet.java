//注文更新機能

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.Order;
import dao.OrderDAO;
import dao.UniformDAO;
import util.SendMail;

public class UpdateOrderServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";
		String cmd = "";

		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("admin");
		SendMail sendMail = new SendMail();
		try {
			if (admin == null) {
				error = "セッション切れの為、注文情報の更新は出来ません。";
				cmd = "top";
				return;
			}

			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String orderID = request.getParameter("orderId"); //
			String payment = request.getParameter("paymentFlag"); //入金
			String shipping = request.getParameter("shippingFlag");	//発送
			String remind = request.getParameter("remindFlag");	//入金催促
			OrderDAO orderDao = new OrderDAO();
			UniformDAO uniformDao = new UniformDAO();

			//チェック入ってたら
			Order order = orderDao.selectByOrderId(orderID);
			int paymentFlag = order.getPaymentFlag();
			int shipmentFlag = order.getShipmentFlag();
			if(payment != null) {
				paymentFlag = 1;
				sendMail.PaymentMail(order,uniformDao.getUniformName(order.getUniformId()) );
				orderDao.update(order.getOrderId(),paymentFlag,shipmentFlag);
				return;
			}else {
				order.setPaymentFlag(order.getPaymentFlag());

			}

			if(shipping != null) {
				shipmentFlag = 1;
				sendMail.Shipmentmail(order,uniformDao.getUniformName(order.getUniformId()) );
				orderDao.update(order.getOrderId(),paymentFlag,shipmentFlag);
				return;
			}else {
				order.setShipmentFlag(order.getShipmentFlag());
			}
			//入金催促
			if(remind !=null) {
				sendMail.RemindMail(order,uniformDao.getUniformName(order.getUniformId()));
				return;
				//メール送る
			}
		}catch(IllegalStateException e) {
			error = "DB接続エラーのため、書籍詳細は表示できませんでした。";
			cmd = "top";

		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/orderList").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
