package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class UpdateUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {
			HttpSession session = request.getSession();

			//DAOオブジェクト宣言
			UserDAO userDao = new UserDAO();

			User user = (User)session.getAttribute("user");
			if (user == null) {
				error = "セッション切れの為、ユーザー情報の更新は出来ません。";
				cmd = "top";
				return;
			}


			//文字エンコード
			request.setCharacterEncoding("UTF-8");

			//パラメータ取得
			String name = user.getName();
			String mail = request.getParameter("mail");
			String password = request.getParameter("password");
			String address = request.getParameter("address");


			//空文字チェック
			if(mail.equals("")) {
				mail = user.getMail();

			}
			if(password.equals("")) {
				password = user.getPassword();

			}
			if(address.equals("")) {
				address = user.getAddress();
			}

			//セッターメソッド呼び出し
			user.setName(name);
			user.setMail(mail);
			user.setPassword(password);
			user.setAddress(address);

			//更新メソッド呼び出し
			userDao.update(user);

			//セッションスコープに登録
			session.setAttribute("user", user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー情報の更新は行えませんでした。";
			cmd = "top";

		} finally {
			//フォワード
			request.setAttribute("cmd", cmd);
			if(error.equals("")) {
				//エラーがない場合
				request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
			} else {
				//エラーがある場合
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}



	}


}
