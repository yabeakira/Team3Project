package servlet;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class InsertUserServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {
			//登録情報格納用オブジェクト生成
			User user = new User();

			//DAOオブジェクト宣言
			UserDAO userDao = new UserDAO();

			//文字エンコード
			request.setCharacterEncoding("UTF-8");

			//パラメータ取得
			String name = request.getParameter("name");
			String mail = request.getParameter("mail");
			String password = request.getParameter("password");
			String address = request.getParameter("address");

			//空文字チェック
			if(name.equals("")) {
				error = "名前が未入力の為、ユーザー登録は行えませんでした。";
				cmd = "top";
				return;
			}
			if(mail.equals("")) {
				error = "メールアドレスが未入力の為、ユーザー登録は行えませんでした。";
				cmd = "top";
				return;
			}
			if(password.equals("")) {
				error = "パスワードが未入力の為、ユーザー登録は行えませんでした。";
				cmd = "top";
				return;
			}
			if(address.equals("")) {
				error = "住所が未入力の為、ユーザー登録は行えませんでした。";
				cmd = "top";
				return;
			}

			//セッターメソッド呼び出し
			user.setName(name);
			user.setMail(mail);
			user.setPassword(password);
			user.setAddress(address);

			//データ重複チェック
			if(userDao.selectByMail(user.getMail()).getMail() != null){
				//データが取得出来た場合重複
				error = "入力したメールアドレスは既に登録済みの為、ユーザー登録は行えませんでした。";
				cmd = "top";
				return;
			}

			//登録メソッド呼び出し
			userDao.insert(user);


		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー登録は行えませんでした。";
			cmd = "top";

		} finally {
			//フォワード
			if(error.equals("")) {
				//エラーがない場合
				request.getRequestDispatcher("/view/topPage.jsp").forward(request, response);
			} else {
				//エラーがある場合
				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}



	}


}
