//購入完了機能

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Order;
import bean.Uniform;
import dao.OrderDAO;
import dao.UniformDAO;
import util.SendMail;



public class PurchaseThankYouServlet extends HttpServlet {

	@SuppressWarnings("null")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";
		SendMail purchaseMail = new SendMail();
		String cmd ="";
		try {

			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String uniformId = request.getParameter("uniformId"); //商品名
			String quantity = request.getParameter("quantity");	//個数
			String name = request.getParameter("name");
			String mail = request.getParameter("mail");
			String address = request.getParameter("address");
			String remarksColumn = request.getParameter("remarksColumn");

			//エラー処理
			if(name.equals("") || mail.equals("") || address.equals("")) {
				error = "情報を入力してください。";
				cmd = "top";
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				return;
			}

			//uniforminfoからuniformId列の全データを取得する
			UniformDAO objUniformDao = new UniformDAO();
			Uniform uniform = objUniformDao.selectByUniformId(uniformId);

			Order order = new Order();
			order.setUniformId(Integer.parseInt(uniformId));
			order.setQuantity(Integer.parseInt(quantity));
			order.setName(name);
			order.setMail(mail);
			order.setAddress(address);
			order.setRemarksColumn(remarksColumn);


			//リクエストスコープに登録
			request.setAttribute("uniform", uniform);
			request.setAttribute("order", order);


			//購入メール送信
			OrderDAO orderDao = new OrderDAO();
			UniformDAO uniformDao = new UniformDAO();
			order.setTotalPrice((int)(uniformDao.selectByUniformId(uniformId).getPrice()*order.getQuantity()*(1+order.getTax())));
			purchaseMail.PurchaseMail(order, uniformDao.getUniformName(order.getUniformId()));
			orderDao.insert(order);
			uniformDao.updateStock(uniformId, uniform.getStock() - order.getQuantity());



		}catch(IllegalStateException e) {
			error = "DB接続エラーのため、書籍詳細は表示できませんでした。";
			cmd = "top";
		}finally {
			if(error.equals("")) {
					request.getRequestDispatcher("/view/purchaseThankYou.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
