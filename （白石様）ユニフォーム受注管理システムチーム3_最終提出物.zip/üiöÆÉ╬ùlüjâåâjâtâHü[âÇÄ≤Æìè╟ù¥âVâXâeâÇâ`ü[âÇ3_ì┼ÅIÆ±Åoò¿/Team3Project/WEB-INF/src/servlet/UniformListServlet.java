package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.Uniform;
import dao.UniformDAO;

public class UniformListServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("admin");
		try {
			// ① UniformDAOをインスタンス化する
			UniformDAO objDao = new UniformDAO();

			// ②関連メソッドを呼び出し、戻り値としてUniformオブジェクトのリストを取得する
			ArrayList<Uniform> list = objDao.selectAll();

			// ③②で取得したListをリクエストスコープに"uniform_list"という名前で格納する
			request.setAttribute("uniform_list", list);

		} catch (Exception e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "top";
		} finally {
			if (error.equals("")) {
				// ④list.jspにフォワード
				if (admin == null) {
					request.getRequestDispatcher("/view/userProductList.jsp").forward(request, response);
				}
				request.getRequestDispatcher("/view/adminProductList.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}
	}
}
