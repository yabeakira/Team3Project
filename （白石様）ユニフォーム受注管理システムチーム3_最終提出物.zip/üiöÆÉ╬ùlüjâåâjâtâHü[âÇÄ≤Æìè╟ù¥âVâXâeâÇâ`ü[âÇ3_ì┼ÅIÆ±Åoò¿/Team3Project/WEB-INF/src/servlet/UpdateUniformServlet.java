package servlet;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import bean.Admin;
import bean.Uniform;
import dao.UniformDAO;
@WebServlet("/updateUniformServlet")
@MultipartConfig
public class UpdateUniformServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラーチェック処理用
		String error = null;
		String cmd = null;
		ServletContext servletContext = getServletContext();
		String projectFolderPath = servletContext.getRealPath("");
		final String absolutePath = projectFolderPath + "/file/pic/"; // ファイルを保存するディレクトリの絶対パス
		final String relativePath = "/file/pic/";//相対パス

		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("admin");

		try {
			if (admin == null) {
				error = "セッション切れの為、商品の更新は出来ません。";
				cmd = "top";
				return;
			}

			// uniformDAOをインスタンス化する
			UniformDAO uniDao = new UniformDAO();

			// エンコード
			request.setCharacterEncoding("UTF-8");

			// name, price, stockの入力パラメータを取得する
			String name = request.getParameter("name");
			String uniformId = request.getParameter("uniformId");
			String price = request.getParameter("price");
			String stock = request.getParameter("stock");
			Uniform oldUniform = uniDao.selectByUniformId(uniformId);
			Uniform uniform = new Uniform();

			// 商品名、価格、在庫がそれぞれ未入力だった時のエラー処理
			if (name.equals("")) {
				uniform.setName(oldUniform.getName());
			} else {
				uniform.setName(name);
			}
			if (price.equals("")) {
				uniform.setPrice(oldUniform.getPrice());
			} else {
				uniform.setPrice(Integer.parseInt(price));
			}
			if (stock.equals("")) {
				uniform.setStock(oldUniform.getStock());
			} else {
				uniform.setStock(Integer.parseInt(stock));
			}

			// Uniformオブジェクトを生成し、商品データを設定

			uniform.setUniformId(Integer.parseInt(uniformId));

			Part filePart = request.getPart("fileToUpload");
			String fileName = getFileName(filePart);
			if (filePart != null && fileName != null && !fileName.isEmpty()) {
				// 元の画像をディレクトリから削除

				Path oldImagePath = Paths.get(projectFolderPath+oldUniform.getPicpass());

				Files.deleteIfExists(oldImagePath);

				// 画像を保存するディレクトリのパス
				String targetDirectory = absolutePath;
				String filePath = targetDirectory + fileName;

				// 画像をディレクトリに保存
				filePart.write(filePath);
				// ファイルの相対パスを生成
				String setPath = relativePath + fileName;
				uniform.setPicpass(setPath);// 相対パスとして設定

			} else {
				// 画像がない場合は変更なしで元の画像パスを設定
				uniform.setPicpass(oldUniform.getPicpass());
			}

			uniDao.update(uniform);

		} catch (NumberFormatException e) {
			error = "入力した値が不正のため、商品更新処理は行えませんでした。";
			cmd = "admin";

		} catch (IllegalStateException e) {
			error = "DB接続エラーのため、商品更新処理は行えませんでした。";
			cmd = "top";

		} finally {
			if (error == null) {
				// uniformListServletにリダイレクト
				response.sendRedirect(request.getContextPath() + "/uniformList");
			} else {
				request.setAttribute("cmd", cmd);
				// エラーのリクエストスコープ登録、error.jspに遷移
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

	private String getFileName(Part part) {
		String contentDisposition = part.getHeader("content-disposition");
		String[] elements = contentDisposition.split(";");
		for (String element : elements) {
			if (element.trim().startsWith("filename")) {
				return element.substring(element.indexOf('=') + 1).trim().replace("\"", "");
			}
		}
		return null;
	}
}
