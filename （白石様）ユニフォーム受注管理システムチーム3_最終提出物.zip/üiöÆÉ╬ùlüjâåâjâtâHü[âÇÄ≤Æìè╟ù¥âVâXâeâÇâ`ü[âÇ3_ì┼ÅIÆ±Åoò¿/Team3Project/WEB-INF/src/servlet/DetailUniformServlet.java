package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Uniform;
import dao.UniformDAO;

public class DetailUniformServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException ,IOException{


		String error = "";
		String cmd = "";

		try {

			//DAOオブジェクト宣言
			UniformDAO uniformDao = new UniformDAO();

			//エンコード
			request.setCharacterEncoding("UTF-8");

			//パラメータ取得
			String uniformId = request.getParameter("uniformId");
			cmd = request.getParameter("cmd");
			if(cmd == null) {
				error ="表示対象のユニフォームが存在しない為、詳細情報は表示できませんでした。";
				cmd = "top";
				return;
			}

			//Bookオブジェクト生成、削除書籍情報格納
			Uniform uniform = uniformDao.selectByUniformId(uniformId);

			//スコープに登録
			request.setAttribute("uniform",uniform);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、書籍詳細は表示できませんでした。";
			cmd = "top";

		} finally {

			if (cmd.equals("detail")) {
				request.getRequestDispatcher("/view/itemDetail.jsp").forward(request, response);

			} else if(cmd.equals("update")) {
				request.getRequestDispatcher("/view/updateUniform.jsp").forward(request, response);

			} else {
				//エラーがある場合
				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}


	}


}
