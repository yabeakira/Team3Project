package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.Order;
import dao.OrderDAO;

public class SearchOrderServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";
		request.setCharacterEncoding("UTF-8");
		String userName = request.getParameter("userName");
		String uniformName = request.getParameter("uniformName");
		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("admin");
		try {
			if (admin == null) {
				error = "セッション切れの為、注文の確認は出来ません。";
				cmd = "top";
				return;
			}

			// オブジェクト宣言
			OrderDAO orderDao = new OrderDAO();

			ArrayList<Order> orderlist = null;
			orderlist = orderDao.search(userName,uniformName);

			// 当月分売上
			int orderPriceSum = orderDao.orderPriceSum();

			// 先月分売上
			int lastMonthOrderPriceSum = orderDao.lastMonthOrderPriceSum();
			request.setAttribute("orderPriceSum", orderPriceSum);
			request.setAttribute("lastMonthOrderPriceSum", lastMonthOrderPriceSum);

			request.setAttribute("orderlist", orderlist);
		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入状況確認は行えませんでした。";
			cmd = "top";
		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/view/orderedStatusList.jsp").forward(request, response);
			} else {
				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
