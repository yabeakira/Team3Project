package bean;

public class Admin {

	//変数宣言
	private String adminId;
	private String password;
	private String name;

	public Admin() {
		this.adminId = null;
		this.password = null;
		this.name= null;
	}

	//ゲッターメソッド・セッターメソッド
	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}