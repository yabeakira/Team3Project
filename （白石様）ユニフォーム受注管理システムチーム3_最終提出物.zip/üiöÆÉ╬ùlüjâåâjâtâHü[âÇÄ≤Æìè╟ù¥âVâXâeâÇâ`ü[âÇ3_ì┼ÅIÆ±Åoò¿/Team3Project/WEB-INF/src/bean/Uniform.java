package bean;
//商品情報（ユニフォームID、name、price、stock、pic pass）を一つのオブジェクトとしてまとめるためのDTOクラス

public class Uniform {

	//ユニフォームの商品ID
	private int uniformId;

	//名前
	private String name;

	//価格
	private int price;

	//在庫
	private int stock;

	//画像
	private String picpass;

	//コンストラクタ
	public Uniform() {
		this.uniformId = 0;
		this.name = "";
		this.price = 0;
		this.stock = 0;
		this.picpass = "";
	}

	//商品IDのセッターとゲッター
	public void setUniformId(int uniformId){
		this.uniformId = uniformId;
	}
	public int getUniformId() {
		return this.uniformId;
	}

	//名前のセッターとゲッター
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return this.name;
	}

	//価格のセッターとゲッター
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPrice() {
		return this.price;
	}

	//在庫のセッターとゲッター
	public void setStock(int stock) {
		this.stock = stock;
	}
	public int getStock() {
		return this.stock;
	}
	//画像のセッターとゲッター
	public void setPicpass(String picpass) {
		this.picpass = picpass;
	}
	public String getPicpass() {
		return this.picpass;
	}
}
