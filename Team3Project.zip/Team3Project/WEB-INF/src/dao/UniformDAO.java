package dao;

import java.sql.*;

import java.util.ArrayList;
import bean.Uniform;

public class UniformDAO {

	/**
	 * JDBCドライバ内部のDriverクラスパス
	 */
	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	/**
	 * 接続するMySQLデータベースパス
	 */
	private static final String URL = "jdbc:mysql://localhost/uniformdb";
	/**
	 * データベースのユーザー名
	 */
	private static final String USER = "root";
	/**
	 * データベースのパスワード
	 */
	private static final String PASSWD = "root123";

	/**
	 * フィールド変数の情報を基に、DB接続をおこなうメソッド
	 *
	 * @return データベース接続情報
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public ArrayList<Uniform> selectAll() {

		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// return用オブジェクト
		ArrayList<Uniform> list = new ArrayList<Uniform>();

		// SQL文
		String sql = "SELECT * FROM uniforminfo ORDER BY ISBN";

		try {
			// SQL文送信準備
			con = UniformDAO.getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をオブジェクトに格納
			while (rs.next()) {
				Uniform uniform = new Uniform();
				uniform.setUniformId(rs.getInt("uniformId"));
				uniform.setName(rs.getString("name"));
				uniform.setPrice(rs.getInt("price"));
				uniform.setStock(rs.getInt("stock"));
				uniform.setPicpass(rs.getString("pic_pass"));

				list.add(uniform);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}

	public Uniform selectByUniformId(String uniformId) {

		Connection con = null;
		Statement smt = null;

		Uniform uniform = new Uniform(); // 検索した書籍情報を格納するUniformオブジェクト

		try {

			// 引数の情報を利用し、検索用のSQL文を文字列として定義
			String sql = "SELECT * FROM uniforminfo where uniformId='" + uniformId + "'";

			// UniforomDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWD);

			// ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			// Statementオブジェクトの、executeQuery（）メソッドを利用、発行したSQL文で結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			// 結果セットから書籍データを取り出し、Bookオブジェクトに格納
			while (rs.next()) {
				uniform.setUniformId(rs.getInt("uniformId"));
				uniform.setName(rs.getString("name"));
				uniform.setPrice(rs.getInt("price"));
				uniform.setStock(rs.getInt("stock"));
				uniform.setPicpass(rs.getString("picpass"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return uniform;
	}

	public void delete(String uniformId) {

		Connection con = null;
		Statement smt = null;

		try {
			// 引数の情報を利用し、削除用のSQL文を定義
			String sql = "DELETE FROM uniforminfo WHERE uniformId = '" + uniformId + "'";

			con = getConnection();
			smt = con.createStatement();

			int rowsCount = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public void update(Uniform uniform) {

		Connection con = null;
		Statement smt = null;

		try {
			// 引数の情報を利用し、更新用のSQL文を定義
			String sql = "UPDATE uniforminfo SET price='" + uniform.getPrice() + "',stock='" + uniform.getStock()
					+ "',picPass=" + uniform.getPicpass() + "WHERE UniformId='" + uniform.getUniformId() + "'";

			con = getConnection();
			smt = con.createStatement();
			int rowsCount = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public ArrayList<Uniform> search(String name) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Uniform> uniformList = new ArrayList<Uniform>();

		try {
			String sql = "SELECT * FROM uniforminfo " + "WHERE name LIKE '%" + name + "%'";

			con = getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Uniform uniform = new Uniform();
				uniform.setUniformId(rs.getInt("uniformId"));
				uniform.setName(rs.getString("name"));
				uniform.setPrice(Integer.parseInt(rs.getString("price")));
				uniform.setStock(Integer.parseInt(rs.getString("stock")));
				uniform.setPicpass(rs.getString("picpass"));
				uniformList.add(uniform);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return uniformList;
	}

	// ユニフォーム登録メソッド
	public void insert(Uniform uniform) {

		Connection con = null;
		Statement smt = null;

		String sql = "insert into uniforminfo (name,price,stock,pic_pass) values('" + uniform.getName() + "','"
				+ uniform.getPrice() + "','" + uniform.getStock() + "','" + uniform.getPicpass() + "')";

		try {
			// DB接続
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

}
