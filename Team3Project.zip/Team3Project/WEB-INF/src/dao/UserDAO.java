
package dao;

import java.sql.*;
import bean.User;


public class UserDAO {

	//DB接続情報
	private static String RDB_DRIVE ="com.mysql.jdbc.Driver";
	private static String URL ="jdbc:mysql://localhost/uniformdb";
	private static String USER ="root";
	private static String PASSWD ="root123";

	//DB接続メソッド
	private static Connection getConnection() {

		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	//指定ユーザーの条件に合致する情報を取得するメソッド
	public User selectByMail(String mail) {

		Connection con = null;
		Statement smt = null;

		//return用オブジェクト生成
		User user = new User();

		String sql ="SELECT * FROM userinfo WHERE mail ='"+mail+"'";

		try {
			//DB接続
			con = getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//結果セット格納
			while (rs.next()) {
				user.setUserId(rs.getInt("userid"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setMail(rs.getString("mail"));
				user.setAddress(rs.getString("address"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {smt.close();} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {con.close();} catch (SQLException ignore) {}
			}
		}
		return user;
	}

	//指定ユーザーとパスワードの条件に合致する情報を取得するメソッド
	public User selectByMail(String mail, String password) {

		Connection con = null;
		Statement smt = null;

		//return用オブジェクト生成
		User user = new User();

		String sql ="SELECT * FROM userinfo WHERE mail ='"+mail+"' AND password='"+password+"'";

		try {
			//DB接続
			con = getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//結果セット格納
			while (rs.next()) {
				user.setUserId(rs.getInt("user"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setMail(rs.getString("mail"));
				user.setAddress(rs.getString("address"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {smt.close();} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {con.close();} catch (SQLException ignore) {}
			}
		}
		return user;
	}

	//ユーザー登録メソッド
	public void insert(User user) {

		Connection con = null;
		Statement smt = null;

		String sql = "insert into userinfo (password,name,mail,address) values('" +user.getPassword() +"','" +user.getName()+ "','"+user.getMail()+"','"+user.getAddress()+"')";

		try {
			//DB接続
			con = getConnection();
			smt = con.createStatement();

			//SQL文発行
			smt.executeUpdate(sql);


		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {smt.close();} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {con.close();} catch (SQLException ignore) {}
			}
		}
	}

	//ユーザー情報更新メソッド
	public void update(User user) {

		Connection con = null;
		Statement smt = null;

		String sql = "UPDATE userinfo SET name='"+user.getName()+"',mail="+user.getMail()+"',password="+user.getPassword()+"',address="+user.getAddress()+" WHERE UserId='"+user.getUserId()+"'";


		try {
			//DB接続
			con = getConnection();
			smt = con.createStatement();

			//SQL文発行
			smt.executeUpdate(sql);


		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {smt.close();} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {con.close();} catch (SQLException ignore) {}
			}
		}
	}
}
