package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Order;

public class OrderDAO {
	// データベース接続情報
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/uniformdb";
	private static String USER = "root";
	private static String PASS = "root123";

	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	//全選択メソッド
	public ArrayList<Order> selectAll() {

		Connection con = null;
		Statement smt = null;

		ArrayList<Order> OrderList = new ArrayList<Order>();
		// SQL文
		String sql = "select oi.orderId, name, address, mail, paymentFlag,shipmentFlag, date,remarksColumn, uniformId,quantity,tax,totalPrice "
				+ "from orderinfo as oi join orderpriceinfo as op on oi.orderid = op.orderid order by date desc";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果を配列に格納
			while (rs.next()) {
				Order order = new Order();
				order.setOrderId(rs.getInt("orderID"));
				order.setName(rs.getString("name"));
				order.setAddress(rs.getString("address"));
				order.setMail(rs.getString("mail"));
				order.setPaymentFlag(rs.getInt("paymentFlag"));
				order.setShipmentFlag(rs.getInt("shipmentFlag"));
				order.setUniformId(rs.getInt("uniformId"));
				order.setQuantity(rs.getInt("quantity"));
				order.setTax(rs.getDouble("tax"));
				order.setTotalPrice(rs.getInt("totalPrice"));
				order.setDate(rs.getString("date"));
				OrderList.add(order);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return OrderList;
	}
	//登録メソッド
	public void insert(Order order) {
		Connection con = null;
		Statement smt = null;

		String orderSql = "INSERT INTO orderinfo (name,address,mail,paymentFlag,shipmentFlag,remarksColumn) values('"
				+ order.getName() + "','" + order.getAddress() + "','" + order.getMail() + "'," + order.getPaymentFlag()
				+ "," + order.getShipmentFlag() + ",'" + order.getRemarksColumn() + "')";
		String priceSql = "insert into orderpriceinfo(orderId,uniformId,quantity,tax,totalPrice) values("
				+ "last_insert_id()" + "," + order.getUniformId() + "," + order.getQuantity() + "," + order.getTax()
				+ "," + order.getTotalPrice() + ")";
		try {

			// ※ここに処理を記述
			// DBに接続
			con = OrderDAO.getConnection();
			smt = con.createStatement();

			// SQL文発行
			smt.executeUpdate(orderSql);
			smt.executeUpdate(priceSql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
	//更新メソッド
	public void update(int orderId,int paymentFlag, int shipmentFlag) {
		Connection con = null;
		Statement smt = null;

		String sql = "UPDATE orderinfo SET  paymentFlag = "+paymentFlag + ", shipmentFlag = "+ shipmentFlag + " WHERE orderId =" + orderId ;


		try {

			// ※ここに処理を記述
			// DBに接続
			con = OrderDAO.getConnection();
			smt = con.createStatement();

			// SQL文発行
			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
}