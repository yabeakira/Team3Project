//売り上げ計算機能

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Uniform;
import bean.User;
import dao.UniformDAO;
import dao.UserDAO;



public class PurchaseServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";

		try {

			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String uniformId = request.getParameter("uniformId"); //商品名
			String quantity = request.getParameter("quantity");	//個数

			//uniforminfoからuniformId列の全データを取得する
			UniformDAO objUniformDao = new UniformDAO();
			Uniform uniform = objUniformDao.selectByUniformId(uniformId);

			//リクエストスコープに登録
			request.setAttribute("uniform", uniform);
			request.setAttribute("uniformId", uniformId);
			request.setAttribute("quantity", quantity);


			//ログインしてたら
			//パラメータの取得
			String mail = request.getParameter("mail"); //メアド
			String password = request.getParameter("password");	//パスワード
			if(mail != null & password != null) {
				UserDAO objUserDao = new UserDAO();
				User objuser = objUserDao.selectByMail(mail);
				request.setAttribute("userdetail", objuser);
			}

			//


		}catch(IllegalStateException e) {
			error = "DB接続エラーのため、書籍詳細は表示できませんでした。";
		}finally {
			if(error.equals("")) {
				String cmd = request.getParameter("cmd");
				if(cmd != null) {
					request.getRequestDispatcher("/view/purchaseThankYou.jsp").forward(request, response);
				}else {
					request.getRequestDispatcher("/view/purchaseForm.jsp").forward(request, response);
				}
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
