//情報を入力し、購入メールを送信する(購入された個数分、在庫を減らす)サーブレット

package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SalesCalculationServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

		String error = "";


	}

}
