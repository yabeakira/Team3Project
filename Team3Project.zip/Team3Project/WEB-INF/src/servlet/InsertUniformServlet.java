package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import bean.Uniform;
import dao.UniformDAO;

@WebServlet("/InsertUniformServlet")
@MultipartConfig
public class InsertUniformServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラーチェック処理用
		String error = null;
		String cmd = null;// uniformDAOをインスタンス化する
		UniformDAO uniDao = new UniformDAO();
		// 登録データを格納する用
		Uniform uniform = new Uniform();

		request.setCharacterEncoding("UTF-8");
		String targetDirectory = "C:/usr/kis_java_pkg_ver4.8/workspace/Team3Project/file/pic/"; // ファイルを保存するフォルダのパス
		Part filePart = request.getPart("fileToUpload"); // アップロードされたファイルのパートを取得
		String fileName = getFileName(filePart); // ファイル名を取得
		String filePath = targetDirectory + fileName; // ファイルの保存先パス

		// ファイルを指定したフォルダに保存する
		try (OutputStream out = new FileOutputStream(new File(filePath));
				InputStream fileContent = filePart.getInputStream()) {
			int read;
			byte[] buffer = new byte[1024];
			while ((read = fileContent.read(buffer)) != -1) {
				out.write(buffer, 0, read);
			}


			String name = request.getParameter("name");
			String price = request.getParameter("price");
			String stock = request.getParameter("stock");

			// 各書籍データが未入力だった時のエラー処理
			if (name.equals("")) {
				error = "商品名が未入力のため、商品登録処理は行えませんでした。";
				cmd = "adminProductList";
			} else if (price.equals("")) {
				error = "価格が未入力のため、商品登録処理は行えませんでした。";
				cmd = "adminProductList";
			} else if (stock.equals("")) {
				error = "在庫が未入力のため、商品登録処理は行えませんでした。";
				cmd = "adminProductList";
			}
//						else if( picPass.equals("") ) {
//						error = "画像が未入力のため、商品登録処理は行えませんでした。";
//						cmd = "adminProductList";
//					}

			//uniform = uniDao.selectByUniformId(name);
			// 商品名データの重複エラー
		/*	if (uniform.getName() != null) {
				error = "商品名は既に登録済みのため、商品登録処理は行えませんでした。";
				cmd = "adminProductList";
				return;
			}*/

			uniform.setName(name);
			uniform.setPrice(Integer.parseInt(price));
			uniform.setStock(Integer.parseInt(stock));
			uniform.setPicpass(filePath);

			// 関連メソッドを呼び出し、戻り値としてUniformオブジェクトのリストを取得する
			uniDao.insert(uniform);
		} catch (FileNotFoundException e) {
			error = "ファイルアップロードエラーが発生しました";
		} catch (NumberFormatException e) {
			error = "価格の値が不正のため、商品情報登録処理は行えませんでした。";
		} catch (IllegalStateException e) {
			error = "DB接続エラーのため、商品登録処理は行えませんでした。";
		} finally {
			if (error == null) {
				// AdminProductListServletにフォワード
				//一旦メニューに飛ばしてます　矢部
				response.setContentType("text/html; charset=UTF-8");
				request.getRequestDispatcher("/view/adminMenu.jsp").forward(request, response);
			} else {
				request.setAttribute("cmd", cmd);
				// エラーのリクエストスコープ登録、error.jspに遷移
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

	private String getFileName(Part part) {
		String contentDisposition = part.getHeader("content-disposition");
		String[] elements = contentDisposition.split(";");
		for (String element : elements) {
			if (element.trim().startsWith("filename")) {
				return element.substring(element.indexOf('=') + 1).trim().replace("\"", "");
			}
		}
		return null;
	}
}
