package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Order;
import bean.Admin;
import dao.OrderDAO;

public class OrderListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		request.setCharacterEncoding("UTF-8");
	/*
	 * HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("admin");
		try {
			if (admin == null) {
				error = "セッション切れの為、注文の確認は出来ません。";
				cmd = "logout";
				return;
			}

	*/
		try {
			// オブジェクト宣言
			OrderDAO orderDao = new OrderDAO();
			ArrayList<Order> orderlist = null;
			orderlist = orderDao.selectAll();
			request.setAttribute("orderlist", orderlist);
		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入状況確認は行えませんでした。";
			cmd = "logout";
		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/view/orderedStatusList.jsp").forward(request, response);
			} else {
				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
