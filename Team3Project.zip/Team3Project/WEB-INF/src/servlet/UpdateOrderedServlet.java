//注文更新機能

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Order;
import dao.OrderDAO;

public class UpdateOrderedServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";

		try {

			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String orderID = request.getParameter("orderId"); //
			String payment = request.getParameter("paymentFlag"); //入金
			String shipping = request.getParameter("shippingFlag");	//発送



			//チェック入ってたら
			Order order = new Order();
			if(payment != null) {
				order.setPaymentFlag(Integer.parseInt(payment));
			}else {
				order.setPaymentFlag(0);
			}

			if(shipping != null) {
				order.setShipmentFlag(Integer.parseInt(shipping));
			}else {
				order.setShipmentFlag(0);
			}
			order.setOrderId(Integer.parseInt(orderID));
			int orderId = order.getOrderId();
			int paymentFlag = order.getShipmentFlag();
			int shippingFlag = order.getShipmentFlag();

			OrderDAO orderDao = new OrderDAO();
			orderDao.update(orderId,paymentFlag,shippingFlag);


			//入金催促
			//パラメータの取得
			String cmd = request.getParameter("cmd");
			if(cmd.equals("0")) {
				//メール送る
			}



		}catch(IllegalStateException e) {
			error = "DB接続エラーのため、書籍詳細は表示できませんでした。";
		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/view/orderListServlet").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
