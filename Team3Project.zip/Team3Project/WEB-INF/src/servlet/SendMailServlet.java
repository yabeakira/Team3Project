//注文更新機能

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Order;
import util.SendMail;

public class SendMailServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";
		SendMail reply = new SendMail();

		try {

			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

//			Order order = (Order)request.getAttribute("order");
//			String mail = order.getMail();

			String mail = "okano44okano@gmail.com";

			//パラメータの取得
			String mailText = request.getParameter("mailText"); //メール本文

			reply.SendMail(mail,mailText);

		}catch(IllegalStateException e) {
			error = "DB接続エラーのため、書籍詳細は表示できませんでした。";
		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/view/orderedStatusList.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
