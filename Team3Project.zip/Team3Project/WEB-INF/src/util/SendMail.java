package util;

import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import bean.Order;
import bean.User;

import javax.mail.internet.InternetAddress;

public class SendMail {

	public void SendMail(String mail, String mailText) {


		try {
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(
				props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						//メールサーバにログインするメールアドレスとパスワードを設定
						return new PasswordAuthentication("test.sender@kanda-it-school-system.com", "kandaSender202208");
					}
				}
			);
//
			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage.setFrom(new InternetAddress("test.sender@kanda-it-school-system.com", "神田IT School", "iso-2022-jp"));

			// 送信先メールアドレスを指定（ご自分のメールアドレスに変更）

			mimeMessage.setRecipients(Message.RecipientType.TO, mail);

			// メールのタイトルを指定
			mimeMessage.setSubject("【自動送信】購入確認メール", "iso-2022-jp");

			// メールの内容を指定

			String message = mailText;

			mimeMessage.setText(message, "iso-2022-jp");



			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("送信に失敗しました。\n" + e);
		}



	}

	//購入メール送信
	public void SendMail(String mail, Order order) {


		try {
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(
				props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						//メールサーバにログインするメールアドレスとパスワードを設定
						return new PasswordAuthentication("test.sender@kanda-it-school-system.com", "kandaSender202208");
					}
				}
			);
//
			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage.setFrom(new InternetAddress("test.sender@kanda-it-school-system.com", "神田IT School", "iso-2022-jp"));

			// 送信先メールアドレスを指定（ご自分のメールアドレスに変更）

			mimeMessage.setRecipients(Message.RecipientType.TO, mail);

			// メールのタイトルを指定
			mimeMessage.setSubject("【自動送信】購入確認メール", "iso-2022-jp");

			// メールの内容を指定

//			String message = order.getName() + "様\r\n\r\nユニフォームのご購入ありがとうざいます。\r\n以下内容でご注文を受け付けましたので、ご連絡致します。\r\n\r\n";



			String message = "様\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"ユニフォームのご購入ありがとうざいます。\\r\\n以下内容でご注文を受け付けましたので、ご連絡致します。\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"ユニフォーム：\\r\\n\r\n" +
					"価格：\\r\\n\r\n" +
					"個数：\\r\\n\r\n" +
					"合計金額：\\r\\n\r\n" +
					"配送先住所：\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"下記口座までお振込みいただきますようお願い申し上げます。\\r\\n\r\n" +
					"振込先口座\\r\\n\r\n" +
					"XX銀行　XX支店　XXXXXX\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"神田ユニフォーム\\r\\n\r\n";

			mimeMessage.setText(message, "iso-2022-jp");



			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("送信に失敗しました。\n" + e);
		}
	}


//催促メール送信
	public void SendMail(String mail) {


		try {
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(
				props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						//メールサーバにログインするメールアドレスとパスワードを設定
						return new PasswordAuthentication("test.sender@kanda-it-school-system.com", "kandaSender202208");
					}
				}
			);
//
			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage.setFrom(new InternetAddress("test.sender@kanda-it-school-system.com", "神田IT School", "iso-2022-jp"));

			// 送信先メールアドレスを指定（ご自分のメールアドレスに変更）

			mimeMessage.setRecipients(Message.RecipientType.TO, mail);

			// メールのタイトルを指定
			mimeMessage.setSubject("商品代金未入金のご確認とお支払のお願い", "iso-2022-jp");

			// メールの内容を指定

//			String message = order.getName() + "様\r\n\r\nユニフォームのご購入ありがとうざいます。\r\n以下内容でご注文を受け付けましたので、ご連絡致します。\r\n\r\n";



			String message = "様\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"先日は当店をご利用いただき誠にありがとうございます。\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"現在、お客様のご注文が、ご入金待ちの状態となっております。\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"誠に恐れ入りますが、このメールをご確認いただきましたら\\r\\n\r\n" +
					"ご注文内容をご確認の上、下記の当店指定口座まで\\r\\n\r\n" +
					"お支払のお手続きをお願いいたします。\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"ユニフォーム：\\r\\n\r\n" +
					"価格：\\r\\n\r\n" +
					"個数：\\r\\n\r\n" +
					"合計金額：\\r\\n\r\n" +
					"配送先住所：\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"下記口座までお振込みいただきますようお願い申し上げます。\\r\\n\r\n" +
					"振込先口座\\r\\n\r\n" +
					"XX銀行　XX支店　XXXXXX\\r\\n\r\n" +
					"\\r\\n\r\n" +
					"神田ユニフォーム\\r\\n";

			mimeMessage.setText(message, "iso-2022-jp");



			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("送信に失敗しました。\n" + e);
		}
	}
}