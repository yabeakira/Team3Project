package bean;
public class Order {
	private int orderId;		//注文番号
	private String name;		//注文者名
	private String address;		//注文者住所
	private String mail;		//注文者メールアドレス
	private int paymentFlag;	//入金フラグ
	private int shipmentFlag;	//発送フラグ
	private String date;		//購入日
	private String remarksColumn;//備考欄
	private int uniformId;	//ユニフォームid
	private int quantity;//個数
	private double tax;//消費税率
	private int totalPrice;	//合計金額

	public Order() {//初期化コンストラクタ
		this.orderId = 0;
		this.name = null;
		this.address = null;
		this.mail = null;
		this.paymentFlag = 0;
		this.shipmentFlag = 0;
		this.date = null;
		this.remarksColumn = "";
		this.uniformId = 0;
		this.quantity = 0;
		this.tax = 0.10;//消費税だけ入れてます
		this.totalPrice = 0;
	}
	//各種getter及びsetter
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderID) {
		this.orderId = orderID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public int getPaymentFlag() {
		return paymentFlag;
	}
	public void setPaymentFlag(int paymentFlag) {
		this.paymentFlag = paymentFlag;
	}
	public int getShipmentFlag() {
		return shipmentFlag;
	}
	public void setShipmentFlag(int shippingFlag) {
		this.shipmentFlag = shippingFlag;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getRemarksColumn() {
		return remarksColumn;
	}
	public void setRemarksColumn(String remarksColumn) {
		this.remarksColumn = remarksColumn;
	}
	public int getUniformId() {
		return uniformId;
	}
	public void setUniformId(int uniformId) {
		this.uniformId = uniformId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}
}
